﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;


namespace Upload
{
    internal class DAL
    {
        private readonly string _connectionString;

        public DAL(string connectionString)
        {
            _connectionString = connectionString;
        }
        public SqlConnection Connect()
        {
            SqlConnection connection = new SqlConnection(_connectionString);
            connection.Open();
            return connection;
        }

        public void Add(int Id,string title,string genre,decimal price)
        {
            string query = "INSERT INTO tblMovie2 (Id,MovieTitle,MovieGenre,MovieSellingPrice) VALUES (@Id,@MovieTitle,@MovieGenre,@MovieSellingPrice)";

            using (SqlConnection connection = Connect())
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", Id);
                command.Parameters.AddWithValue("@MovieTitle",title);
                command.Parameters.AddWithValue("@MovieGenre", genre);
                command.Parameters.AddWithValue("@MovieSellingPrice", price);
                
                int rowsAffected = command.ExecuteNonQuery();
                Console.WriteLine("Rows Inserted Successfully " + rowsAffected);
            }
        }
        
        public void Update(int Id,string title,string genre,decimal price)
        {
            string query = "UPDATE tblMovie2 SET MovieTitle=@MovieTitle,MovieGenre=@MovieGenre,MovieSellingPrice=@MovieSellingPrice Where id = @Id";

            using (SqlConnection connection = Connect())
            {
                SqlCommand command = new SqlCommand(query,connection);
                command.Parameters.AddWithValue("@Id", Id);
                command.Parameters.AddWithValue("@MovieTitle", title);
                command.Parameters.AddWithValue("@MovieGenre", genre);
                command.Parameters.AddWithValue("@MovieSellingPrice", price);

                int rowsAffected = command.ExecuteNonQuery();
                Console.WriteLine("Rows Updated Successfully " + rowsAffected);
            }
        }
        
        public void Delete(int id)
        {
            string query = "DELETE FROM tblMovie2 WHERE Id = @Id";

            using (SqlConnection connection = Connect())
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", id);

                int rowsAffected = command.ExecuteNonQuery();
                Console.WriteLine("Rows Deleted Successfully " + rowsAffected);
            }
        }

        public DataTable Search(string searchText)
        {
            string query = "SELECT Id, MovieTitle, MovieGenre, MovieSellingPrice FROM tblMovie2 WHERE MovieTitle LIKE @SearchText OR MovieGenre LIKE @SearchText OR CAST(Id AS VARCHAR) LIKE @SearchText";

            using (SqlConnection connection = Connect())
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@SearchText", "%" + searchText + "%"); // Using wildcards for partial matches

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable); // Fill DataTable with search results

                return dataTable;
            }
        }
    }
}