﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using Microsoft.Win32;


namespace Upload
{
    public partial class Upload : Form
    {
        public Upload()
        {
            InitializeComponent();
            LoadMovies();


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        string url = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\User\\OneDrive\\Documentos\\movieDB.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=False;";


        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Id = int.Parse(id.Text);
            string Title = title.Text;
            string Genre = genre.Text;
            decimal Price = decimal.Parse(price.Text);

            DAL dal = new DAL(url);
            dal.Add(Id, Title, Genre,Price);

            LoadMovies();
        }

        public void LoadMovies()
        {
            string query = " SELECT Id,movieTitle,movieGenre,movieSellingPrice From tblMovie2 ";

            using (SqlConnection connection = new SqlConnection(url))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query,connection);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                dataGridView1.Rows.Clear();

                foreach(DataRow row in dataTable.Rows)
                {
                    dataGridView1.Rows.Add(row["Id"], row["movieTitle"], row["movieGenre"], row["movieSellingPrice"]);
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Id = int.Parse(id.Text);
            string Title = title.Text;
            string Genre = genre.Text;
            decimal Price = decimal.Parse(price.Text);

            DAL dal = new DAL(url);
            dal.Update(Id, Title, Genre, Price);
                
            LoadMovies();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int Id = int.Parse(id.Text);

            DAL dal = new DAL(url);
            dal.Delete(Id);

            LoadMovies();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
                string searchText = search.Text; // Assuming you have a TextBox named searchTextBox for search input
                DAL dal = new DAL(url);
                DataTable searchResult = dal.Search(searchText);  // Call the Search method in DAL class

                dataGridView1.Rows.Clear();

                foreach (DataRow row in searchResult.Rows)
                {
                    dataGridView1.Rows.Add(row["Id"], row["MovieTitle"], row["MovieGenre"], row["MovieSellingPrice"]);
                }
            }

        }
    }